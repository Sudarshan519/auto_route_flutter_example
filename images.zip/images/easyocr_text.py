import easyocr
reader = easyocr.Reader(['ja','en'])

result=reader.readtext('images/jap/app_flutter1679484244555.png',detail=0)
print(result)